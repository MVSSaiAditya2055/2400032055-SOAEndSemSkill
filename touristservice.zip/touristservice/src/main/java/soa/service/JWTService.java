package soa.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Service
public class JWTService {

    final String SECKEY = "qwertyuioplkjhgfdsazxcvbnm1234567890";
    final SecretKey key = Keys.hmacShaKeyFor(SECKEY.getBytes());

    // Generate Token
    public Object generateToken(String username, String role)
    {
        Map<String, Object> payload = new HashMap<>();

        payload.put("username", username);
        payload.put("role", role);

        return Jwts.builder()
                .claims(payload)
                .issuedAt(new Date())
                .expiration(new Date(new Date().getTime() + 86400000))
                .signWith(key)
                .compact();
    }

    // Validate Token
    public Claims validateToken(String token)
    {
        return Jwts.parser()
                .verifyWith(key)
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }
}